# Lead Automation System

A comprehensive system for automating lead generation, outreach, and sales processes.

## Features

### 1. Lead Generation from Apollo.io
- Search and enrich leads from Apollo.io API
- Target business owners in U.S. (digital agencies, coaches, SaaS founders)
- Target business owners in India (startups, small businesses, agencies)
- Filter based on industry, revenue, and location
- Store results in Google Sheets (no API required)

### 2. Automated Email Outreach
- Connect Gmail for India leads and Outlook for U.S. leads
- Send personalized emails with the lead's first name & business type
- Follow up every 3 days (max 4 times)
- Stop emails when the lead replies or books a call

### 3. Lead Engagement Handling
- Provide options for sending call links or email responses
- Send Calendly link automatically when requested
- Track lead status in Google Sheets

### 4. Payment Processing
- Dynamic pricing based on lead location
  - U.S.: $2,500 - $5,000
  - India: ₹40,000 - ₹1,50,000
- Integrated payment gateways
  - Stripe for U.S. leads
  - Razorpay for India leads
- Flexible payment options

### 5. Analytics and Tracking
- Track email open rates, replies, and call bookings
- Visualize sales funnel performance
- Get suggestions to improve conversions

## Technical Stack

- Frontend: HTML, CSS, JavaScript (with Bootstrap and Chart.js)
- Backend: Python with Flask
- Storage: Google Sheets (for simplicity and no-API integration)
- Email: SMTP integration with Gmail and Outlook
- Payments: Stripe and Razorpay APIs

## Installation and Setup

1. Clone the repository
2. Install backend dependencies:
   ```
   cd backend
   pip install -r requirements.txt
   ```
3. Configure your environment variables in `.env` file
4. Run the backend:
   ```
   python app.py
   ```
5. Open `frontend/index.html` in your browser or serve with a static file server

## Environment Variables

Create a `.env` file in the backend directory with the following variables:

```
# API Keys and Credentials
APOLLO_API_KEY=your_apollo_api_key
GMAIL_USERNAME=your_gmail_username
GMAIL_PASSWORD=your_gmail_app_password
OUTLOOK_EMAIL=your_outlook_email
OUTLOOK_PASSWORD=your_outlook_app_password

# Payment Gateway Credentials
STRIPE_API_KEY=your_stripe_api_key
STRIPE_SECRET_KEY=your_stripe_secret_key
RAZORPAY_KEY_ID=your_razorpay_key_id
RAZORPAY_KEY_SECRET=your_razorpay_secret_key

# Google Sheets Integration
GOOGLE_SHEETS_CREDENTIALS=path/to/your/credentials.json
LEAD_SHEET_ID=your_google_sheet_id

# Application Settings
APP_SECRET_KEY=your_secret_key
DEBUG=True
PORT=5000
```

## Google Sheets Setup

1. Create a Google Cloud Platform project
2. Enable the Google Sheets API
3. Create credentials (service account)
4. Download the JSON credentials file
5. Share your Google Sheet with the service account email
6. Update the `GOOGLE_SHEETS_CREDENTIALS` and `LEAD_SHEET_ID` environment variables

## Usage

1. Configure your API credentials in Settings
2. Find leads using the Apollo.io integration
3. Start outreach campaigns to leads
4. Monitor responses and handle follow-ups
5. Send payment links and track conversions
6. Analyze your sales funnel performance

## License

This project is licensed under the MIT License.
